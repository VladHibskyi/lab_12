// Завдання 2
console.log('Hibskyi');

// Завдання 3
let variable1 = 'some value';
let variable2 = 10;

console.log(variable1);
console.log(variable2);

variable2 = variable1;

console.log(variable1);
console.log(variable2);

// Завдання 4
let dataTypes = {
    String: 'Hello',
    Number: 42,
    Boolean: true,
    Undefined: undefined,
    Null: null
};

console.log(dataTypes);

// Завдання 5
let isAdult = confirm('Достигли ви повнолітнього віку?');
console.log(isAdult);

// Завдання 6
let name = 'Vlad';
let surname = 'Hibskyi';
let group = 'KN-323';
let yearOfBirth = 2006;
let isMarried = false;

console.log(typeof yearOfBirth); // Number
console.log(typeof isMarried);   // Boolean
console.log(typeof name);        // String

let nullVar = null;
let undefinedVar;
console.log(typeof nullVar);     // object
console.log(typeof undefinedVar);// undefined

// Завдання 8
let secondsInHour = 60 * 60;
let secondsInDay = secondsInHour * 24;
let secondsInMonth = secondsInDay * 31; // Припущення, що місяць має 31 день

console.log('Кількість секунд в годині:', secondsInHour);
console.log('Кількість секунд в добі:', secondsInDay);
console.log('Кількість секунд в місяці:', secondsInMonth);
